**Project Description**
MVC Music Store is a tutorial application built on ASP.NET MVC. It's a lightweight sample store which demonstrates ASP.NET MVC using Entity Framework.

## Overview
* Demonstrates ASP.NET MVC 3 Templating, Data Annotations, and Validation
* Demonstrates Razor syntax and advanced features
* Shows Client-Side Validation, jQuery, and use of AJAX helper methods
* Includes store browse, shopping cart, checkout, and membership
* Shows data access via Entity Framework 4
* Illustrates use of ViewModels
* This tutorial requires [Visual Web Developer 2010 Express](http://www.microsoft.com/express/Web/) and ASP.NET 4.0 (both free) or Visual Studio 2010

Read the full tutorial online [on the ASP.NET website](http://www.asp.net/mvc/tutorials/mvc-music-store-part-1).

_To view administrative pages use this login: Username = Administrator / password = password123!_
_A SQL Express database is included, but if you need SQL scripts to create the database they are available [here](Home_MvcMusicStore-SQL2005.sql)_

![MVC Music Store](Home_PDF-Icon.jpg|http://mvcmusicstore.codeplex.com/releases/view/64379#DownloadId=228002)
**Includes a 160-page PDF Walkthrough Tutorial inside the ZIP file!**

![MVC Music Store](Home_MVC-Music-Store-Thumb.png)

## License
* Open Source Ms-PL license
 